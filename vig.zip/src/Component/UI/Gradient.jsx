export const Gradient = ({className}) => (
  <div className={`absolute bg-gradient-effect z-0 ${className || ''}`}></div>
);
